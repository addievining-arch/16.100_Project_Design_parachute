import numpy as np
import matplotlib.pyplot as plt

# given variables
m_pay, R_req, reserve = 0.50, 20e3, 1.10
b_max, Vstall_max = 1.6, 7.0
e_osw, CLmax, CD0 = 0.80, 1.40, 0.035
e_star, f_use, eta, P_max = 150.0, 0.90, 0.60, 150.0
rho, g = 1.225, 9.81
rho_foam, tau, A_fac = 25.2, 0.12, 0.66
m_f0, m_fb, m_fS, S0, b0 = 0.3, 0.15, 0.08, 0.16, 1.1

# change these values
MB = 0.127
S_grid = np.linspace(0.10, 0.60, 101)
AR_grid = np.linspace(4.0, 20.0, 101)
V_MARGIN = 1.0
V_MAX = 60.0
S = 0.383 # chosen S
AR = 4.4 # chose AR

# given equations
def geometry(S, AR):
    b = np.sqrt(S * AR)
    return b, S / b

def mass(S, AR, mb):
    b, c = geometry(S, AR)
    m_wing = rho_foam * A_fac * tau * c**2 * b
    m_fuse = m_f0 + m_fb * b / b0 + m_fS * S / S0
    return m_pay + m_wing + m_fuse + mb

# calc stuffs for contours
def evaluate(S, AR, mb, nV=400):
    b, _ = geometry(S, AR)
    W = mass(S, AR, mb) * g
    Vs = np.sqrt(2 * W / (rho * S * CLmax))
    LD_req = reserve * W * R_req / (eta * f_use * e_star * 3600 * mb)
    t = np.linspace(0, 1, nV)
    V = (V_MARGIN * Vs)[..., None] + t * (V_MAX - V_MARGIN * Vs)[..., None]
    CL = 2 * W[..., None] / (rho * V**2 * S[..., None])
    CD = CD0 + CL**2 / (np.pi * e_osw * AR[..., None])
    LD = CL / CD
    P = W[..., None] * V / (eta * LD)
    ok_range = (LD >= LD_req[..., None]) & (CL <= CLmax)
    ok_both = ok_range & (P <= P_max)
    Vcruise = np.max(np.where(ok_both, V, -np.inf), axis=-1)
    Vcruise = np.where(ok_both.any(-1), Vcruise, np.nan)
    return dict(Vs=Vs, T_min=R_req / Vcruise / 60,
                fail_range=~ok_range.any(-1),
                fail_power=ok_range.any(-1) & ~ok_both.any(-1),
                fail_span=b > b_max, fail_land=Vs > Vstall_max)

SS, AA = np.meshgrid(S_grid, AR_grid)
r = evaluate(SS, AA, MB)

fig, ax = plt.subplots(figsize=(9, 6.5))

def shade(mask, color, label):
    ax.contourf(SS, AA, mask.astype(float), levels=[0.5, 1.5], colors=[color], alpha=0.35)
    ax.plot([], [], 's', color=color, alpha=0.5, label=label)

shade(r['fail_range'], 'tab:red', 'fails range')
shade(r['fail_power'], 'tab:orange', 'fails Pmax')
shade(r['fail_span'], 'tab:purple', f'span > {b_max} m')
shade(r['fail_land'], 'tab:gray', f'Vstall > {Vstall_max:g} m/s')

# defining contours and plotting
cs = ax.contour(SS, AA, r['Vs'], levels=[5, 6, 7, 8, 9, 10], colors='k', linewidths=1)
ax.clabel(cs, fmt='Vstall=%g', fontsize=8)
ax.contour(SS, AA, r['Vs'], levels=[Vstall_max], colors='k', linewidths=2.5)
cT = ax.contour(SS, AA, r['T_min'], colors='tab:blue', linestyles='--', linewidths=1)
ax.clabel(cT, fmt='%.0f min', fontsize=8)
ax.plot(S_grid, b_max**2 / S_grid, 'm-', lw=2.5, label=f'b = {b_max} m')
ax.plot(S, AR, 'k*', ms=15, mec='w', label='chosen design')

ax.set_xlim(S_grid[0], S_grid[-1])
ax.set_ylim(AR_grid[0], AR_grid[-1])
ax.set_xlabel('Wing area S [m$^2$]')
ax.set_ylabel('Aspect ratio AR')
ax.set_title(f'Design space, battery mass = {MB} kg (unshaded = feasible)')
ax.plot([], [], 'k-', label='Vstall contours')
ax.plot([], [], 'b--', label='flight-time contours')
ax.legend(loc='upper right', fontsize=8)
plt.tight_layout()
plt.savefig('figure_A.png', dpi=200)
plt.show()
