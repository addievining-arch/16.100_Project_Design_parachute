import numpy as np
import matplotlib.pyplot as plt

# given variables
m_pay, R_req, reserve = 0.50, 20e3, 1.10
b_max, Vstall_max = 1.6, 7.0
e_osw, CLmax, CD0 = 0.80, 1.40, 0.035
e_star, f_use, eta, P_max = 150.0, 0.90, 0.60, 150.0
rho, g = 1.225, 9.81
rho_foam, tau, A_fac = 25.2, 0.12, 0.66
m_f0, m_fb, m_fS, S0, b0 = 0.3, 0.15, 0.08, 0.16, 1.1

# change these values
S_CHOSEN = 0.383
AR_CHOSEN = 4.4
MB_CHOSEN = 0.127
V_MARGIN = 1.0
V_MAX = 60.0

# given equ
def geometry(S, AR):
    b = np.sqrt(S * AR)
    return b, S / b

def mass(S, AR, mb):
    b, c = geometry(S, AR)
    m_wing = rho_foam * A_fac * tau * c**2 * b
    m_fuse = m_f0 + m_fb * b / b0 + m_fS * S / S0
    return m_pay + m_wing + m_fuse + mb

# plotting multiple battery masses
mb_curves = [MB_CHOSEN - 0.02, MB_CHOSEN, MB_CHOSEN + 0.03, MB_CHOSEN + 0.08, MB_CHOSEN + 0.15]
R_need_km = reserve * R_req / 1000

def range_curve(mb, nV=4000):
    S, AR = np.array(S_CHOSEN), np.array(AR_CHOSEN)
    W = mass(S, AR, mb) * g
    Vs = np.sqrt(2 * W / (rho * S * CLmax))
    V = np.linspace(V_MARGIN * Vs, V_MAX, nV)
    CL = 2 * W / (rho * V**2 * S)
    LD = CL / (CD0 + CL**2 / (np.pi * e_osw * AR))
    R_km = eta * f_use * e_star * 3600 * mb * LD / W / 1000
    power = W * V / (eta * LD)
    feasible = (R_km >= R_need_km) & (power <= P_max) & (CL <= CLmax)
    return V, R_km, power, feasible

fig, ax = plt.subplots(figsize=(9, 6))
for mb in mb_curves:
    V, R_km, power, feasible = range_curve(mb)
    chosen = np.isclose(mb, MB_CHOSEN)
    line, = ax.plot(V, R_km, lw=3 if chosen else 1.2,
                    label=f'm_b = {mb:.3f} kg' + (' (chosen)' if chosen else ''))
    i_min = np.argmin(power)
    over = np.where(power[i_min:] > P_max)[0]
    if len(over):
        j = i_min + over[0]
        ax.plot(V[j], R_km[j], 'o', color=line.get_color(), ms=8)

ax.axhline(R_need_km, color='k', ls='--', label=f'required: {R_need_km:.0f} km (20 km + 10% reserve)')
ax.plot([], [], 'ko', label='power reaches Pmax')
ax.set_xlim(0, 40)
ax.set_ylim(0, None)
ax.set_xlabel('Cruise speed V [m/s]')
ax.set_ylabel('Range with usable battery energy [km]')
ax.set_title(f'Range vs cruise speed, S = {S_CHOSEN} m$^2$, AR = {AR_CHOSEN}')
ax.legend(fontsize=8)
plt.tight_layout()
plt.savefig('figure_B.png', dpi=200)
plt.show()
